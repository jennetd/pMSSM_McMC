* TLhrvars.h
* this file is part of FeynHiggs
* generated 2-Aug-2016 18:25

	ComplexType selfA0A0, selfh0A0, selfh0h0, selfh0HH, selfHHA0
	ComplexType selfHHHH, selfHmHp, tadA0, tadh0, tadHH
	ComplexType Cc(1909), Cd(12687), Ce(2089), Co(2685), Cr(140)
	ComplexType dAf133eps(-1:1), dMf133eps(-1:1)
	ComplexType dMSfsq1133eps(-1:1), dMSfsq1143eps(-1:1)
	ComplexType dMSfsq1233eps(-1:1), dY33eps(-1:1), Opt(20)
	common /hrvar/ selfA0A0, selfh0A0, selfh0h0, selfh0HH
	common /hrvar/ selfHHA0, selfHHHH, selfHmHp, tadA0, tadh0
	common /hrvar/ tadHH, Cc, Cd, Ce, Co, Cr, dAf133eps
	common /hrvar/ dMf133eps, dMSfsq1133eps, dMSfsq1143eps
	common /hrvar/ dMSfsq1233eps, dY33eps, Opt

